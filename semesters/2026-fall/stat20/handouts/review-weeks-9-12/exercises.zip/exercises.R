library(tidyverse)
icecream <- read_csv("data/icecream.csv")
new_icecream <- read_csv("data/new_icecream.csv")
driving <- read_csv("data/driving.csv")
new_driving <- read_csv("data/new_driving.csv")
cars_train <- read_csv("data/cars_train.csv")
cars_test <- read_csv("data/cars_test.csv")
penguins_sample <- read_csv("data/penguins_sample.csv")
resumes <- read_csv("data/resumes.csv")

# --- c1a ---
# Explore icecream and fit a simple linear model
icecream |>
  summarize(
    mean_temp = ___,
    mean_cones = ___,
    r = ___
  )

m_ice <- lm(___, data = icecream)
coef(m_ice)


# --- c1b ---
# Uses m_ice from above: predict on new_icecream and compute test RMSE
new_eval <- new_icecream |>
  mutate(
    pred = predict(m_ice, newdata = new_icecream),
    resid = ___
  )
new_eval
sqrt(mean(new_eval$resid^2))


# --- c2a ---
# Fit linear vs quadratic stopping-distance models on driving
m_lin <- lm(dist_ft ~ speed_mph + wet_road, data = driving)
m_quad <- lm(___, data = driving)
c(lin_r2 = summary(m_lin)$r.squared, quad_r2 = summary(m_quad)$r.squared)
coef(m_quad)


# --- c2b ---
# Evaluate linear vs quadratic test RMSE on new_driving
rmse <- function(y, yhat) sqrt(mean((y - yhat)^2))
c(
  lin_test_rmse = rmse(new_driving$dist_ft, ___),
  quad_test_rmse = rmse(new_driving$dist_ft, ___)
)


# --- c3a ---
# Compare additive vs interaction used-car price models
m_car_add <- lm(price_k ~ age_yr + mileage_k + hybrid, data = cars_train)
m_car_int <- lm(price_k ~ age_yr * hybrid + mileage_k, data = cars_train)
coef(m_car_int)
c(add_r2 = summary(m_car_add)$r.squared, int_r2 = summary(m_car_int)$r.squared)


# --- c3b ---
# Fit an overly flexible polynomial and compare test RMSE on cars_test
m_car_over <- lm(price_k ~ poly(age_yr, 6, raw = TRUE) * hybrid + poly(mileage_k, 3, raw = TRUE), data = cars_train)
rmse <- function(y, yhat) sqrt(mean((y - yhat)^2))
c(
  add_test = rmse(cars_test$price_k, predict(m_car_add, newdata = cars_test)),
  int_test = rmse(cars_test$price_k, predict(m_car_int, newdata = cars_test)),
  over_test = ___
)


# --- c4a ---
# Group-wise summary of bill length by species
penguins_sample |>
  group_by(species) |>
  summarize(
    count = n(),
    mean_bill = ___,
    sd_bill = ___
  )


# --- c4b ---
# 1000-replicate bootstrap 95% percentile CI for Adelie mean bill length
adelie <- penguins_sample |> filter(species == "Adelie") |> pull(bill_length_mm)
set.seed(20)
boot_means <- replicate(1000, ___)
quantile(boot_means, c(0.025, 0.975))


# --- c5a ---
# Logistic regression for callback probability
m_log <- glm(callback ~ exp_years + honors, data = resumes, family = binomial)
coef(m_log)
exp(coef(m_log))  # odds ratios


# --- c5b ---
# Classify at threshold 0.5 and compute MCR, precision, recall
p_hat <- predict(m_log, type = "response")
y_hat <- as.integer(p_hat >= 0.5)
y <- resumes$callback
tp <- sum(y == 1 & y_hat == 1)
fp <- sum(y == 0 & y_hat == 1)
fn <- sum(y == 1 & y_hat == 0)
c(mcr = ___, precision = ___, recall = ___)

