# STAT 20 Review (Weeks 9-12): Case Studies

Open `exercises.R` in RStudio with the `data/` folder in your working directory, or use the browser page `exercises.html`.
