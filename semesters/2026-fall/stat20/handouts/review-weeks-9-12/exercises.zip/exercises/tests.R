# Tests for review.R. Run from this folder:  Rscript tests.R
# To check the solutions instead:  Rscript tests.R ../solutions/review.R
args <- commandArgs(trailingOnly = TRUE)
source(if (length(args) > 0) args[1] else "review.R")

check <- function(name, expr) {
  ok <- tryCatch(isTRUE(expr), error = function(e) FALSE)
  cat(if (ok) "PASS" else "FAIL", name, "\n")
}
near <- function(a, b, tol = 1e-6) all(abs(a - b) < tol)

set.seed(1)
b <- tryCatch(boot_stats(c(2, 4, 6, 8), mean, 200), error = function(e) NULL)
check("boot_stats: one statistic per resample", length(b) == 200)
check("boot_stats: values from resamples", length(b) == 200 && all(b >= 2 & b <= 8))
check("boot_stats: all values equal gives one point", all(boot_stats(c(5, 5, 5), mean, 50) == 5))
check("boot_stats: n = 1 gives one point", all(boot_stats(7, median, 20) == 7))
check("boot_stats: max never exceeds the sample max", max(boot_stats(c(1, 9, 3, 4), max, 300)) == 9)

check("percentile_ci: 95% of 1..101", near(percentile_ci(1:101, 0.95), c(3.5, 98.5)))
check("percentile_ci: 99% contains 95%", {
  s <- rnorm(500); a <- percentile_ci(s, 0.95); w <- percentile_ci(s, 0.99)
  w[1] <= a[1] && w[2] >= a[2]
})
check("percentile_ci: no names", is.null(names(percentile_ci(1:10, 0.9))))

null <- c(rep(-3, 40), rep(0, 448), rep(3, 12))
check("two_sided_p: right tail smaller", near(two_sided_p(null, 3), 0.048))
check("two_sided_p: left tail smaller", near(two_sided_p(null, -3), 0.16))
check("two_sided_p: capped at 1", two_sided_p(null, 0) == 1)
check("two_sided_p: ties count as extreme", near(two_sided_p(c(1, 2, 3, 4), 4), 0.5))

check("chisq_stat: die", near(chisq_stat(c(5, 8, 9, 8, 10, 20), rep(1/6, 6)), 13.4))
check("chisq_stat: perfect match is 0", chisq_stat(c(25, 75), c(0.25, 0.75)) == 0)

check("ls_coef: hand example", near(ls_coef(1:4, c(2, 3, 5, 6)), c(0.5, 1.4)))
check("ls_coef: agrees with lm", near(ls_coef(c(0, 1, 2), c(1, 1, 4)), unname(coef(lm(c(1, 1, 4) ~ c(0, 1, 2))))))
check("ls_coef: constant x", {
  r <- ls_coef(c(3, 3, 3), c(1, 2, 6)); r[1] == 3 && is.na(r[2])
})

check("r_squared: hand example", near(r_squared(c(2, 3, 5, 6), c(1.9, 3.3, 4.7, 6.1)), 0.98))
check("r_squared: negative on test data", near(r_squared(c(1, 2, 3), c(3, 3, 3)), -1.5))
check("r_squared: baseline gives 0", near(r_squared(c(1, 2, 6), c(3, 3, 3)), 0))

check("logistic: values", near(logistic(c(0, 1, -1)), c(0.5, 0.7310586, 0.2689414)))
check("classify: 0.5 is 1", identical(classify(c(0.49, 0.5, 0.9)), c(0, 1, 1)))

m <- tryCatch(metrics(c(rep(1, 10), rep(0, 90)), c(rep(1, 6), rep(0, 4), rep(1, 2), rep(0, 88))), error = function(e) NULL)
check("metrics: spam filter", near(m, c(0.06, 0.75, 0.6)) && identical(names(m), c("mcr", "precision", "recall")))
check("metrics: no positive predictions", {
  z <- metrics(c(1, 0, 0, 0), c(0, 0, 0, 0)); near(z[["mcr"]], 0.25) && is.nan(z[["precision"]]) && z[["recall"]] == 0
})

check("binom_test_power: n = 10, p1 = 0.8", near(binom_test_power(10, 0.5, 0.8, 0.05), c(9, 11/1024, 0.3758096)))
check("binom_test_power: too few tosses", near(binom_test_power(4, 0.5, 0.9, 0.05), c(5, 0, 0)))
check("binom_test_power: size at most alpha", binom_test_power(30, 0.5, 0.7, 0.05)[["size"]] <= 0.05)
