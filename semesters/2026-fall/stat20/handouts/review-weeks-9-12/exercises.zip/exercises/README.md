# STAT 20 review, Weeks 9-12: R exercises

Base R only (no packages). Fill in each function in `review.R`, then run

    Rscript tests.R

Every test prints PASS or FAIL. The functions are the computations from the review handout:

1. `boot_stats`: bootstrap statistics (resamples of size n, with replacement). For a single number `x`, `sample(x)` draws from `1:x`; index with `sample.int` instead.
2. `percentile_ci`: the bootstrap percentile interval.
3. `two_sided_p`: twice the smaller tail, capped at 1, ties counted as extreme.
4. `chisq_stat`: the chi-squared statistic.
5. `ls_coef`: the least squares line, with `NA` slope when all x are equal.
6. `r_squared`: R^2 against the baseline mean of the same y (negative on bad test predictions).
7. `logistic`, `classify`: the logistic function and the 0.5 threshold (0.5 gives 1).
8. `metrics`: misclassification rate, precision, recall (0/0 gives NaN).
9. `binom_test_power`: the exact rejection region, size and power of a one-sided count test.
