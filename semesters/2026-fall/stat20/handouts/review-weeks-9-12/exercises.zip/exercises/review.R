# STAT 20 review, Weeks 9-12: exercises in base R.
# Fill in each function body (replace stop("todo")), then run
#   Rscript tests.R
# from this folder. Every test prints PASS or FAIL.

# 1. Bootstrap: `reps` statistics, each `stat` applied to a resample of x
#    (size length(x), with replacement). Returns a numeric vector.
#    It must work when x has length 1.
boot_stats <- function(x, stat, reps) {
  stop("todo")
}

# 2. Percentile interval: the (1 - level)/2 and (1 + level)/2 quantiles of
#    `stats` (use quantile() with its default type). Returns a length-2
#    numeric vector with no names.
percentile_ci <- function(stats, level) {
  stop("todo")
}

# 3. Two-sided p-value from a null distribution, as infer computes it:
#    twice the smaller of mean(null >= obs) and mean(null <= obs), capped at 1.
two_sided_p <- function(null_stats, obs) {
  stop("todo")
}

# 4. Chi-squared statistic: observed counts and null proportions p
#    (same order, p sums to 1).
chisq_stat <- function(observed, p) {
  stop("todo")
}

# 5. Least squares line: c(b0, b1) from the formulas
#    b1 = Sxy / Sxx, b0 = mean(y) - b1 * mean(x).
#    If all x are equal, return c(mean(y), NA), as lm() does.
ls_coef <- function(x, y) {
  stop("todo")
}

# 6. R^2 of predictions y_hat for targets y, with the baseline mean(y)
#    taken from the same y (so it can be negative on a test set).
r_squared <- function(y, y_hat) {
  stop("todo")
}

# 7. Logistic function and classification with threshold 0.5 (p >= 0.5 -> 1).
logistic <- function(t) {
  stop("todo")
}
classify <- function(p_hat) {
  stop("todo")
}

# 8. Metrics for 0/1 vectors y and y_hat: a named vector
#    c(mcr = , precision = , recall = ); 0/0 gives NaN.
metrics <- function(y, y_hat) {
  stop("todo")
}

# 9. Exact size and power of the one-sided test of H0: p = p0 against
#    HA: p > p0 with n tosses that rejects when X >= c, where c is the
#    smallest count with P(X >= c | p0) <= alpha. Returns
#    c(c = , size = , power = ) with power computed at p1.
#    If no count qualifies, c is n + 1 and size and power are 0.
binom_test_power <- function(n, p0, p1, alpha) {
  stop("todo")
}
