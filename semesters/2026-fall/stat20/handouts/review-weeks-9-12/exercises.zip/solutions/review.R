# STAT 20 review, Weeks 9-12: solutions to exercises/review.R.

boot_stats <- function(x, stat, reps) {
  # x[sample.int(n, ...)], not sample(x, ...): for a single number x, sample(x) draws from 1:x
  n <- length(x)
  replicate(reps, stat(x[sample.int(n, size = n, replace = TRUE)]))
}

percentile_ci <- function(stats, level) {
  unname(quantile(stats, probs = c((1 - level) / 2, (1 + level) / 2)))
}

two_sided_p <- function(null_stats, obs) {
  min(1, 2 * min(mean(null_stats >= obs), mean(null_stats <= obs)))
}

chisq_stat <- function(observed, p) {
  expected <- sum(observed) * p
  sum((observed - expected)^2 / expected)
}

ls_coef <- function(x, y) {
  sxx <- sum((x - mean(x))^2)
  if (sxx == 0) return(c(mean(y), NA))
  b1 <- sum((x - mean(x)) * (y - mean(y))) / sxx
  c(mean(y) - b1 * mean(x), b1)
}

r_squared <- function(y, y_hat) {
  1 - mean((y - y_hat)^2) / mean((y - mean(y))^2)
}

logistic <- function(t) {
  1 / (1 + exp(-t))
}
classify <- function(p_hat) {
  ifelse(p_hat >= 0.5, 1, 0)
}

metrics <- function(y, y_hat) {
  tp <- sum(y == 1 & y_hat == 1)
  fp <- sum(y == 0 & y_hat == 1)
  fn <- sum(y == 1 & y_hat == 0)
  c(mcr = mean(y != y_hat), precision = tp / (tp + fp), recall = tp / (tp + fn))
}

perm_null <- function(y, group, reps) {
  replicate(reps, {
    g <- sample(group)
    mean(y[g == "a"]) - mean(y[g == "b"])
  })
}

split_rows <- function(n, frac) {
  rows <- sample.int(n)
  k <- floor(n * frac)
  list(train = rows[seq_len(k)], test = rows[setdiff(seq_len(n), seq_len(k))])
}

binom_test_power <- function(n, p0, p1, alpha) {
  # P(X >= k) = 1 - pbinom(k - 1, ...), for k = 0, ..., n
  tail0 <- 1 - pbinom(0:n - 1, n, p0)
  ok <- which(tail0 <= alpha)
  if (length(ok) == 0) return(c(c = n + 1, size = 0, power = 0))
  k <- ok[1] - 1
  c(c = k, size = 1 - pbinom(k - 1, n, p0), power = 1 - pbinom(k - 1, n, p1))
}
