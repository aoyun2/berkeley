library(tidyverse)
salaries <- read_csv("data/salaries.csv")
notes_study <- read_csv("data/notes_study.csv")
gym_warmup <- read_csv("data/gym_warmup.csv")

# --- w1a ---
salaries |> group_by(group) |> summarize(n = n(), mean_sal = mean(salary_k))

salaries |>
  group_by(dept, group) |>
  summarize(n = n(), mean_sal = mean(salary_k))

# --- w1b ---
coef(lm(salary_k ~ group, data = salaries))
coef(lm(salary_k ~ group + dept, data = salaries))

# --- w2a ---
notes_study |>
  group_by(method) |>
  summarize(n = n(), mean_gpa = mean(prior_gpa), mean_score = mean(quiz_score))

obs_ate <- with(notes_study, mean(quiz_score[method == "Longhand"]) - mean(quiz_score[method == "Laptop"]))
obs_ate

# --- w2b ---
set.seed(20)
perm_ates <- replicate(1000, {
  shuffled <- sample(notes_study$method)
  mean(notes_study$quiz_score[shuffled == "Longhand"]) - mean(notes_study$quiz_score[shuffled == "Laptop"])
})
mean(abs(perm_ates) >= abs(obs_ate))

# --- w3a ---
cells <- gym_warmup |>
  group_by(treated, post) |>
  summarize(n = n(), mean_visits = mean(visits_wk))
cells
did_est <- (cells$mean_visits[4] - cells$mean_visits[3]) - (cells$mean_visits[2] - cells$mean_visits[1])
did_est

# --- w3b ---
m_did <- lm(visits_wk ~ treated * post, data = gym_warmup)
coef(m_did)
coef(m_did)["treated:post"]
