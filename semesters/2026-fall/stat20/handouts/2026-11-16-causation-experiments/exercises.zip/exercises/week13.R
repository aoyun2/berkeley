# STAT 20 Week 13 exercises: fill in each function body (base R only). Check with: Rscript tests.R

# 1. Average treatment effect of units whose two potential outcomes are known.
#    ate(c(3, 4, 2, 5), c(5, 4, 6, 7)) is 2.
ate <- function(y_c, y_t) {
  # YOUR CODE HERE
}

# 2. Difference in means, treated minus control. `treated` is TRUE/FALSE for each unit.
#    diff_in_means(c(5, 4, 2, 5), c(TRUE, TRUE, FALSE, FALSE)) is 1.
diff_in_means <- function(y, treated) {
  # YOUR CODE HERE
}

# 3. Every estimate an experiment could produce: treat m of the n units in every possible way
#    (combn), and return the vector of treated-minus-control differences, one per assignment.
#    Unit i shows y_t[i] if treated and y_c[i] if not.
all_estimates <- function(y_c, y_t, m) {
  # YOUR CODE HERE
}

# 4. Standardized mean difference of covariate x, treated minus control, with the pooled
#    standard deviation sqrt(var_t / 2 + var_c / 2). If binary_std is TRUE, x is 0/1 and each
#    group's variance is p * (1 - p) (as in cobalt's binary = "std"); otherwise use var() (n - 1).
smd <- function(x, treated, binary_std = FALSE) {
  # YOUR CODE HERE
}

# 5. Exact two-sided balance-test p-value for covariate x: the null distribution is the difference
#    in means over every assignment of sum(treated) units to treatment; take the tail on the side
#    of the observed difference (>= if it is >= 0, else <=), double it, and cap at 1.
exact_p_value <- function(x, treated) {
  # YOUR CODE HERE
}

# 6. Probability that k special units all land in the same group when m of n units are treated
#    at random (the treated group has m units, the control group n - m).
prob_all_same_group <- function(n, m, k) {
  # YOUR CODE HERE
}
