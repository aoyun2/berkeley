# Week 13 exercises (STAT 20)

Original exercises on causation and randomized experiments, in base R. Write them yourself, without AI help.

`week13.R`: fill in each function where it says `# YOUR CODE HERE`. The comments give the definitions and an example.

Check your work from this folder:

    Rscript tests.R

Solutions are in `../solutions/`. Look only after `tests.R` passes or you have spent 15 minutes stuck on one exercise.
