# Check the Week 13 exercises:  Rscript tests.R   (or Rscript tests.R ../solutions)
args <- commandArgs(trailingOnly = TRUE)
folder <- if (length(args) > 0) args[1] else "."
source(file.path(folder, "week13.R"))

failed <- 0
check <- function(name, got, expected, tol = 1e-6) {
  got <- tryCatch(got, error = function(e) NULL)
  ok <- !is.null(got) && length(got) == length(expected) && all(abs(got - expected) < tol)
  cat(sprintf("%-22s %s\n", name, if (isTRUE(ok)) "ok" else "FAIL"))
  if (!isTRUE(ok)) {
    failed <<- failed + 1
    cat("   expected:", expected, "\n   got:     ", if (is.null(got)) "NULL" else got, "\n")
  }
}
gpa <- c(3.81, 3.63, 3.20, 2.85, 3.19, 3.80)
pdf <- c(TRUE, TRUE, TRUE, FALSE, FALSE, FALSE)
stats_major <- c(1, 0, 0, 1, 0, 1)

check("ate", ate(c(3, 4, 2, 5), c(5, 4, 6, 7)), 2)
check("ate 2", ate(c(1, 3, 2, 6), c(4, 3, 2, 9)), 1.5)
check("diff_in_means", diff_in_means(c(5, 4, 2, 5), c(TRUE, TRUE, FALSE, FALSE)), 1)
check("all_estimates", sort(all_estimates(c(3, 4, 2, 5), c(5, 4, 6, 7), 2)), c(1, 1, 1, 3, 3, 3))
check("unbiased", mean(all_estimates(c(1, 3, 2, 6), c(4, 3, 2, 9), 2)), 1.5)
check("smd GPA", round(smd(gpa, pdf), 4), 0.6566)
check("smd major (n-1)", round(smd(stats_major, pdf), 4), -0.5774)
check("smd major (p(1-p))", round(smd(stats_major, pdf, binary_std = TRUE), 4), -0.7071)
check("exact p GPA", exact_p_value(gpa, pdf), 0.4)
check("exact p P5", exact_p_value(c(10, 12, 14, 20, 30), c(FALSE, FALSE, FALSE, TRUE, TRUE)), 0.2)
check("all same group", prob_all_same_group(4, 2, 2), 1/3)
check("all same group 2", prob_all_same_group(20, 10, 4), 28/323)
cat(if (failed == 0) "all passed\n" else sprintf("%d failed\n", failed))
quit(status = if (failed == 0) 0 else 1)
