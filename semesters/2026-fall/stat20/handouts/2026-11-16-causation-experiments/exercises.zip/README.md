# STAT 20 Week 13: Causation, Experiments & DID

Open `exercises.R` in RStudio with the `data/` folder in your working directory, or use `exercises.html` in a browser.
