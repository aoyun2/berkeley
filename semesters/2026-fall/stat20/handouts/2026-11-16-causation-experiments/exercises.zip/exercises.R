library(tidyverse)
salaries <- read_csv("data/salaries.csv")
notes_study <- read_csv("data/notes_study.csv")
gym_warmup <- read_csv("data/gym_warmup.csv")

# --- w1a ---
# Pooled mean vs stratified mean by dept and group
salaries |> group_by(group) |> summarize(n = n(), mean_sal = mean(salary_k))

salaries |>
  group_by(___, ___) |>
  summarize(n = n(), mean_sal = ___)


# --- w1b ---
# Compare unadjusted vs dept-adjusted regression
coef(lm(salary_k ~ group, data = salaries))
coef(lm(___, data = salaries))


# --- w2a ---
# Balance check on prior_gpa and observed ATE on quiz_score
notes_study |>
  group_by(method) |>
  summarize(n = n(), mean_gpa = ___, mean_score = ___)

obs_ate <- with(notes_study, mean(quiz_score[method == "Longhand"]) - mean(quiz_score[method == "Laptop"]))
obs_ate


# --- w2b ---
# 1000-rep permutation test under the sharp null
set.seed(20)
perm_ates <- replicate(1000, {
  shuffled <- sample(notes_study$method)
  mean(notes_study$quiz_score[shuffled == "Longhand"]) - ___
})
mean(abs(perm_ates) >= abs(obs_ate))


# --- w3a ---
# 2x2 cell means table and hand calculation of DID
cells <- gym_warmup |>
  group_by(treated, post) |>
  summarize(n = n(), mean_visits = mean(visits_wk))
cells

# Extract (T,Post - T,Pre) - (C,Post - C,Pre)


# --- w3b ---
# Verify lm(visits_wk ~ treated * post) interaction equals DID
m_did <- lm(___, data = gym_warmup)
coef(m_did)
coef(m_did)["treated:post"]

