# Week 3 exercises (CS 61A)

Original exercises on lambda, currying, zero-argument functions and exam-style iteration.

1. `week03.py`: fill in each function. Where the docstring says "one lambda expression", the answer is a single `return lambda ...` line.
2. `predict.py`: write what each snippet displays when run as a file.
3. `timed.py`: three exam-style problems. Set a timer for 25 minutes, write the answers ON PAPER first, then type them in and run the tests.

From this folder:

    python3 tests.py
    python3 -m doctest week03.py timed.py

## Timed practice exam (do this before a midterm)

The course publishes past exams with solutions at https://cs61a.org/resources/ . Two good ones for Midterm 1 practice: Fall 2025 Midterm 1 and Summer 2026 Midterm. Print one, allow 50 minutes, closed book except the official Midterm 1 study guide, then mark it with the published solutions.

Solutions to these exercises are in `../solutions/`.
