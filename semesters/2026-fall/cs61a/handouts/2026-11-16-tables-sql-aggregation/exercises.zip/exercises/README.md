# Week 13 exercises (CS 61A)

Original SQL exercises on this week's ideas (tables, select, joins, aggregation). Write them yourself, without AI help, the same way you would a lab.

1. `data.sql` creates the tables `books` and `loans` (shown in the handout).
2. `week13.sql`: replace each `select "YOUR QUERY HERE" as unfinished;` with your query.

Check your work from this folder (Python's built-in sqlite3, no install needed):

    python3 tests.py

Solutions are in `../solutions/`. Look only after `tests.py` passes or you have spent 15 minutes stuck on one exercise.
