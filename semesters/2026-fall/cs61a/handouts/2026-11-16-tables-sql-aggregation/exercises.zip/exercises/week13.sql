-- CS 61A Week 13 exercises: fill in each query. Tables are in data.sql.

-- E1. Titles of books with more than 260 pages, longest first.
create table e1 as
  select "YOUR QUERY HERE" as unfinished;

-- E2. Each author with number of books and total pages (authors with at least two books), by author.
create table e2 as
  select "YOUR QUERY HERE" as unfinished;

-- E3. For each loan: member, title, author.
create table e3 as
  select "YOUR QUERY HERE" as unfinished;

-- E4. Pairs of different books by the same author, each pair once.
create table e4 as
  select "YOUR QUERY HERE" as unfinished;

-- E5. The member with the most total loan days, and the total.
create table e5 as
  select "YOUR QUERY HERE" as unfinished;

-- E6. Authors whose books were borrowed by at least two different members.
create table e6 as
  select "YOUR QUERY HERE" as unfinished;

-- E7. Decade of each book with the number of books from it, oldest first.
create table e7 as
  select "YOUR QUERY HERE" as unfinished;
