"""Check the Week 13 SQL exercises:  python3 tests.py   (or python3 tests.py ../solutions)"""
import os, sqlite3, sys

HERE = os.path.dirname(os.path.abspath(__file__))
FOLDER = sys.argv[1] if len(sys.argv) > 1 else HERE
EXPECTED = {  # (rows, whether the order of the rows matters)
    "e1": ([("Emma",), ("Dune",), ("Valis",), ("Kindred",)], True),
    "e2": ([("Austen", 2, 723), ("Butler", 2, 512), ("Dick", 2, 473)], True),
    "e3": ([("Ana", "Dune", "Herbert"), ("Ben", "Emma", "Austen"), ("Chen", "Dune", "Herbert"),
            ("Ana", "Ubik", "Dick"), ("Ben", "Kindred", "Butler"), ("Dev", "Kindred", "Butler"),
            ("Ana", "Dawn", "Butler")], False),
    "e4": ([("Dawn", "Kindred"), ("Emma", "Persuasion"), ("Ubik", "Valis")], False),
    "e5": ([("Ben", 35)], True),
    "e6": ([("Butler",), ("Herbert",)], False),
    "e7": ([(1810, 2), (1960, 2), (1970, 1), (1980, 2)], True),
}

def main():
    db = sqlite3.connect(":memory:")
    db.executescript(open(os.path.join(HERE, "data.sql")).read())
    try:
        db.executescript(open(os.path.join(FOLDER, "week13.sql")).read())
    except sqlite3.Error as e:
        print("SQL error in week13.sql:", e); return 1
    failed = 0
    for name, (rows, ordered) in EXPECTED.items():
        got = db.execute(f"select * from {name}").fetchall()
        ok = got == rows if ordered else sorted(got) == sorted(rows)
        print(f"{name}: {'ok' if ok else 'FAIL'}")
        if not ok:
            failed += 1
            print("   expected", rows, "(in this order)" if ordered else "(any order)")
            print("   got     ", got)
    print("all passed" if not failed else f"{failed} failed")
    return 1 if failed else 0

if __name__ == "__main__":
    sys.exit(main())
